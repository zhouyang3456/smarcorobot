#include "thread_http.hpp"

thread_http::thread_http()
{

}
