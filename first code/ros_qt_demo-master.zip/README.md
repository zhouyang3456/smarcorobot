# ros_qt_demo

## 更改功能包名称
下载此包或者克隆本包到自己的工作空间src目录下
如果需要更改功能包的名称:
- 使用文本编辑器的查找与替换功能替换```cmakelist.txt```与```package.xml```中的ros_qt_demo为自己想要的名称
![image.png](https://i.postimg.cc/zfZ1s8RB/image.png)
- 更改include目录下的文件夹名称为自己的功能包名称
![image.png](https://i.postimg.cc/X7RhJxN1/image.png)

- 更改src目录下三个cpp文件的的包含目录
![image.png](https://i.postimg.cc/76WjCfgq/image.png)
![image.png](https://i.postimg.cc/8ch8qT6D/image.png)
